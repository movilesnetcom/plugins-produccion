package org.apache.cordova.posPlugin.commands;

import org.apache.cordova.posPlugin.constants.ConstantsCodeResponse;
import org.apache.cordova.posPlugin.dto.ResponseDTO;

/**
 * Created by david.ordaz on 20/03/2018.
 */
public class CommandConnectionDevice {

  public CommandConnectionDevice(){
  }

  public ResponseDTO getConnectDevice(){
    return new ResponseDTO(ConstantsCodeResponse.SUCCESFUL,"Dispositivo Conectado","");
  }

  public ResponseDTO getDisconnectDevice(){
    return new ResponseDTO(ConstantsCodeResponse.SUCCESFUL,"Dispositivo desconectado","");
  }

  public ResponseDTO getIsConnectDevice(boolean isDevicePresent){
    if(isDevicePresent){
      return  new ResponseDTO(ConstantsCodeResponse.SUCCESFUL,"Dispositivo Conectado","");
    }else{
      return new ResponseDTO(ConstantsCodeResponse.FAILED,"Dispositivo No Conectado","");
    }
  }

}
