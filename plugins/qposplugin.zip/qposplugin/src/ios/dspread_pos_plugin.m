//
//  dspread_pos_plugin.m
//  qpos-ios-demo
//
//  Created by dspread-mac on 2018/2/1.
//  Copyright © 2018年 Robin. All rights reserved.
//

#import "dspread_pos_plugin.h"
#import "QPOSUtil.h"
#import <AudioToolbox/AudioToolbox.h>
#import "ParseTLV.h"
typedef void(^imgBlock)(NSString * data);
@interface dspread_pos_plugin()

@property(nonatomic,strong) imgBlock MyBlock;
@property (nonatomic,copy)NSString *terminalTime;
@property (nonatomic,copy)NSString *currencyCode;
@end

//CONSTANTES-------------------------------------------------------
//TIPOS TRANSACCION------------------------------------------------
NSString *QPOS_GetCompanions=@"QPOS_GetCompanions";
NSString *QPOS_getConnectDevice=@"QPOS_getConnectDevice";
NSString *QPOS_IsConnectDevice=@"QPOS_IsConnectDevice";
NSString *QPOS_DisconnectDevice=@"QPOS_DisconnectDevice";
NSString *QPOS_GetStatusBattery=@"QPOS_GetStatusBattery";
NSString *QPOS_ConfigurationInitial=@"QPOS_ConfigurationInitial";
NSString *QPOS_ConfigurationInitialmini=@"QPOS_ConfigurationInitialmini";
NSString *QPOS_ConfigurationInitialcute=@"QPOS_ConfigurationInitialcute";
NSString *QPOS_StartTransaction=@"QPOS_StartTransaction";
NSString *QPOS_DataTransaction=@"QPOS_DataTransaction";
NSString *QPOS_CompleteTransaction=@"QPOS_CompleteTransaction";
NSString *QPOS_STOP_TRANSACTION=@"QPOS_StopTransaction";
NSString *QPOS_IS_INSERT_CARD=@"QPOS_IsInsertCard";
NSString *QPOS_BANDCARDPIN=@"QPOS_BandCardPin";
//ESTADOS TRANSACCIÓN------------------------------------------------
NSString* APPROVAL               =@"1";
NSString* DECLINE                =@"0";
NSString* GET_PIN_STATE          =@"2";
NSString* PROCESSING_STATE       =@"3";
NSString* PLEASE_WAIT_STATE      =@"4";
NSString* WAITING_USER_STATE     =@"5";
NSString* TERMINATED_TRANSACTION =@"6";
NSString* SELECT_APP             =@"7";
NSString* SELECTED_APP           =@"8";
NSString* FALLBACK               =@"9";
NSString* ERROR_SWIPE_CHIP       =@"10";
NSString* GET_SWIPE_PIN       =@"11";
//POST ENTRY MODE TRANSACCIÓN------------------------------------------------
NSString* CHIP      =@"051";
NSString* BAND      =@"021";
NSString* FALL_BACK =@"801";
NSString* CONTACTLESS_CHIP =@"071";
NSString* CONTACTLESS_BAND =@"911";
//AID S------------------------------------------------
NSString* AID_MAESTRO        = @"A0000000043060";
NSString* AID_MASTERCARD     = @"A0000000041010";
NSString* AID_VISA_ELECTRON  = @"A0000000032010";
NSString* AID_VISA_CREDITO   = @"A0000000031010";
NSString* AID_DINNER_CREDITO = @"A0000001523010";
NSString* AID_AMEX           = @"A0000000250104";
NSString* AID_LABEL_DEBIT    = @"DEBIT";
//CARD------------------------------------------------
NSString* MASKED_PAN       = @"maskedPAN";
NSString* EXPIRY_DATE      = @"expiryDate";
NSString* CARDHOLDER_NAME  = @"cardholderName";
NSString* KSN              = @"trackksn";
NSString* KSN_PINBLOCK     = @"pinKsn";
NSString* PINBLOCK         = @"pinBlock";
NSString* TRACK1_LENGTH    = @"track1Length";
NSString* TRACK2_LENGTH    = @"track2Length";
NSString* TRACK3_LENGTH    = @"track3Length";
NSString* TRACK1_ENCRYPT   = @"encTrack1";
NSString* TRACK2_ENCRYPT   = @"encTrack2";
NSString* TRACK3_ENCRYPT   = @"encTrack3";
NSString* TRACK2_SEPARADOR = @"D";
//CODE RESPONSE------------------------------------------------
NSString* SUCCESFUL = @"1";
NSString* FAILED    = @"0";
NSString* ERROR     = @"-1";
//CONNECTION------------------------------------------------
BOOL AUTO            = YES;
NSInteger* BOND_TIME = 180000;
//FRANQUISIA------------------------------------------------
NSString* MAESTRO        = @"MAESTRO";
NSString* MASTERCARD     = @"MASTERCARD";
NSString* VISA_ELECTRON  = @"VISA_ELECTRON";
NSString* VISA_CREDITO   = @"VISA_CREDITO";
NSString* DINNER_CREDITO = @"DINNER_CREDITO";
NSString* AMEX           = @"AMEX";
//INFO QPOS------------------------------------------------
NSString* BOOTLOADER_VERSION   = @"bootloaderVersion";
NSString* IS_SUPPORTED_TRACK_1 = @"isSupportedTrack1";
NSString* IS_SUPPORTED_TRACK_2 = @"isSupportedTrack2";
NSString* IS_SUPPORTED_TRACK_3 = @"isSupportedTrack3";
NSString* FIRMWARE_VERSION     = @"firmwareVersion";
NSString* IS_USB_CONNECTED     = @"isUsbConnected";
NSString* IS_CHARGING          = @"isCharging";
NSString* BATTERY_LEVEL        = @"batteryLevel";
NSString* HARDWARE_VERSION     = @"hardwareVersion";
NSString* BATTERY_PERCENTAGE   = @"batteryPercentage";
//MODE ENTRY---
NSInteger* MODE_MAGNETIC_SWIPE = 1;
NSInteger* MODE_EMV            = 2;
NSInteger* MODE_CONTACTLESS    = 3;
//TRANSACCION---
NSString* CURRENCY_TYPE   = @"0170";
NSString* CENTS           = @"00";
NSString* CASHBACK_AMOUNT = @"0";
//TYPE CARD--------------------------
NSString* AHORRO    = @"10";
NSString* CORRIENTE = @"20";
NSString* CREDITO   = @"30";
NSString* DEBITO    = @"00";
//TAGS-------------------------------
NSString* TAG_5F20 = @"5F20";
NSString* TAG_4F   = @"4F";
NSString* TAG_5F24 = @"5F24";
NSString* TAG_9F16 = @"9F16";
NSString* TAG_9F21 = @"9F21";
NSString* TAG_9A   = @"9A";
NSString* TAG_9F02 = @"9F02";
NSString* TAG_9F03 = @"9F03";
NSString* TAG_9F34 = @"9F34";
NSString* TAG_9F12 = @"9F12";
NSString* TAG_9F06 = @"9F06";
NSString* TAG_5F30 = @"5F30";
NSString* TAG_9F4E = @"9F4E";
NSString* TAG_5A   = @"5A";
NSString* TAG_57   = @"57";
NSString* TAG_8E   = @"8E";
NSString* TAG_5F25 = @"5F25";
NSString* TAG_9F07 = @"9F07";
NSString* TAG_9F0D = @"9F0D";
NSString* TAG_9F0E = @"9F0E";
NSString* TAG_9F0F = @"9F0F";
NSString* TAG_9F39 = @"9F39";
NSString* TAG_9F40 = @"9F40";
NSString* TAG_9F53 = @"9F53";
NSString* TAG_5F28 = @"5F28";
NSString* TAG_9F4C = @"9F4C";
NSString* TAG_50   = @"50";
NSString* TAG_9F08 = @"9F08";
NSString* TAG_9F01 = @"9F01";
NSString* TAG_9F15 = @"9F15";
NSString* TAG_9F1C = @"9F1C";
NSString* TAG_95   = @"95";
NSString* TAG_82   = @"82";
NSString* TAG_84   = @"84";
NSString* TAG_9F09 = @"9F09";
NSString* TAG_5F34 = @"5F34";
NSString* TAG_9F41 = @"9F41";
NSString* TAG_9F27 = @"9F27";
NSString* TAG_9F26 = @"9F26";
NSString* TAG_9F10 = @"9F10";
NSString* TAG_9F37 = @"9F37";
NSString* TAG_9F36 = @"9F36";
NSString* TAG_9F35 = @"9F35";
NSString* TAG_9F33 = @"9F33";
NSString* TAG_9F1A = @"9F1A";
NSString* TAG_9F1E = @"9F1E";
NSString* TAG_5F2A = @"5F2A";
NSString* TAG_9F6E = @"9F6E"; // NUEVO TAG
NSString* TAG_9C   = @"9C";
NSString* TAG_9B   = @"9B";
//-----------------------------------------------------------------------//
/** Tags propios de QPOS*/
NSString* TAG_C4 = @"C4";
NSString* TAG_C1 = @"C1";
NSString* TAG_C7 = @"C7";
NSString* TAG_C0 = @"C0";
NSString* TAG_C2 = @"C2";
NSString* TAG_70 = @"70";
NSString* TAG_C3 = @"C3";
NSString* TAG_C5 = @"C5";
//-------------------------------------------------------------------------//
/** Tags respuesta Emv*/
NSString* TAG_89 = @"89";
NSString* TAG_8A = @"8A";
NSString* TAG_91 = @"91";
NSString* TAG_71 = @"71";
NSString* TAG_72 = @"72";
//VARIABLES------------------------------------------------
NSInteger scanBluetoothTime = 60;
NSInteger scanBluetoothTrieds = 0;
NSInteger TIMER = 0;
NSInteger TIMER_OUT = 5;
NSInteger indexKeyEMV = 0;
NSInteger indexEMV = 2;
NSString* hexLabel;

NSString *listApp = nil;
NSString *stateTx = @"-1";
NSString *address=@"";
NSString *typeCardEntry=@"";

BOOL isSelectApp = NO;
BOOL is2ModeBluetooth = YES;
BOOL isTestBluetooth = NO;
BOOL isConnected = NO;

BOOL isBanda = NO;
BOOL isChip = NO;
BOOL isFallback = NO;

NSString* posEntryMode =@"";
NSString* tipoCuentaId=@"";
NSInteger* tipoEntrada=0;
NSString* cardInfo=@"";

BOOL flagPinSwipe = NO;
BOOL flagUpdata = NO;
BOOL IS_TEST_VERSION = NO;
NSString *pinStringFirstResponse;

NSMutableDictionary *cardInfoForBand;

NSMutableDictionary* object=nil;

@implementation dspread_pos_plugin
{
    QPOSService *mQPOSService;
    BTDeviceFinder *bt;
    NSMutableArray *allBluetooth;
    NSString *btAddress;
    TransactionType mTransType;
    NSString *amount;
    UIAlertView *mAlertView;
    UIActionSheet *mActionSheet;
    PosType     mPosType;
    dispatch_queue_t self_queue;
    NSString *msgStr;
    NSString *nameAction;
    NSTimer* appearTimer;
    CDVInvokedUrlCommand* commandLocal;
}
@synthesize bluetoothAddress;
@synthesize amount;
@synthesize cashbackAmount;


//UTILS---------------------------------------------------------------------------------------------------------------------------------------
-(NSString*)convertDictionaryToString:(NSMutableDictionary*) dict
{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: convertDictionaryToString");
    NSError* error;
    NSDictionary* tempDict = [dict copy]; // get Dictionary from mutable Dictionary
    //giving error as it takes dic, array,etc only. not custom object.
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:tempDict
                                                       options:NSJSONReadingMutableLeaves error:&error];
    NSString* nsJson=  [[NSString alloc] initWithData:jsonData
                                             encoding:NSUTF8StringEncoding];
    return nsJson;
}
-(void) sleepMs: (NSInteger)msec {
    NSLog(@"QPOS_PLUGIN_NATIVE_I: sleepMs");
    NSTimeInterval sec = (msec / 1000.0f);
    [NSThread sleepForTimeInterval:sec];
}
-(NSInteger*) hexaStringToInt:(NSString*)hexa{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: hexaStringToInt");
    NSInteger* decimalValue=0;
    unsigned result = 0;
    hexa = [@"#" stringByAppendingString:hexa];
    NSScanner *scanner = [NSScanner scannerWithString:hexa];
    [scanner setScanLocation:1]; // bypass '#' character
    [scanner scanHexInt:&result];
    NSLog(@"%d:",result);
    decimalValue = result;
    return result;
}
-(NSMutableDictionary*) getTagByname: (NSString*)name: (NSString*)tlv{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getTagByname");
    NSMutableDictionary* tag = nil;
    if(tlv!=nil){
        
        tlv  = [tlv uppercaseString];
        name = [name uppercaseString];
        NSRange posTag = [tlv rangeOfString:name];
        NSLog(@"my posTag is %@", NSStringFromRange(posTag));
         if(posTag.location == 0){
            NSString* len = [tlv substringToIndex:[name length]+2];
            len = [len substringFromIndex:[name length]];
            NSInteger lenDec = [self hexaStringToInt:len];
            lenDec=lenDec*2;
            NSString* value = [tlv substringToIndex:[name length]+2+lenDec];
            value = [value substringFromIndex:[name length]+2];
            NSLog(@"TAG ENCONTRADO NAME %@:",name);
            NSLog(@"TAG ENCONTRADO LEN %@:",len);
            NSLog(@"TAG ENCONTRADO VALUE %@:",value);
            tag = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                   name, @"name",
                   len, @"length",
                   value, @"value",
                   nil];

         }
         //else{
        //     tag = [NSMutableDictionary dictionaryWithObjectsAndKeys:
        //            name, @"name",
        //            @"", @"length",
        //            @"", @"value",
        //            nil];
        // }
    }else{
        tag = [NSMutableDictionary dictionaryWithObjectsAndKeys:
               name, @"name",
               @"", @"length",
               @"", @"value",
               nil];
    }
    return tag;
}

-(NSMutableDictionary*)getTagQposByName: (NSString*)name: (NSString*)tlv{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getTagQposByName");
    NSMutableArray* array = [self getArrayTagQpos];
    NSMutableDictionary* tag = nil;
    
    for(NSInteger i = 0 ; i < [array count] ; i++){
        NSLog(@"TAG QPOS name ---- %@:",[array objectAtIndex:i]);
        NSString *tag_name=[array objectAtIndex:i];
        tag = [self getTagByname:tag_name :tlv];
        NSString* len = tag[@"length"];
        if([tag_name isEqualToString: name]){
            break;
        }
        else if(![len isEqualToString:@""]){
            NSInteger lenDec = [self hexaStringToInt:len];
            lenDec=lenDec*2;
            tlv = [tlv substringFromIndex:[tag_name length]+2+lenDec];
            NSLog(@"TLV DE MONDA %@:",tlv);
        }
    }
    return tag;
}
-(NSMutableArray*) getArrayTagSales{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getArrayTagSales");
    NSMutableArray* array = [[NSMutableArray alloc]init];
    [array addObject:TAG_95];
    [array addObject:TAG_82];
    [array addObject:TAG_84];
    [array addObject:TAG_9A];
    [array addObject:TAG_9C];
    [array addObject:TAG_9F09];
    [array addObject:TAG_5F34];
    [array addObject:TAG_9F41];
    [array addObject:TAG_9F34];
    [array addObject:TAG_9F27];
    [array addObject:TAG_9F26];
    [array addObject:TAG_9F10];
    [array addObject:TAG_9F37];
    [array addObject:TAG_9F36];
    [array addObject:TAG_9F35];
    [array addObject:TAG_9F33];
    [array addObject:TAG_9F1A];
    [array addObject:TAG_9F1E];
    [array addObject:TAG_9F02];
    [array addObject:TAG_5F2A];
    [array addObject:TAG_9F6E];
    [array addObject:TAG_9F03];
    return array;
}
-(NSMutableArray*)getArrayTagQpos{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getArrayTagQpos");
    NSMutableArray* array = [[NSMutableArray alloc]init];
    [array addObject:TAG_5F20];
    [array addObject:TAG_4F];
    [array addObject:TAG_5F24];
    [array addObject:TAG_9F16];
    [array addObject:TAG_9F21];
    [array addObject:TAG_9A];
    [array addObject:TAG_9F02];
    [array addObject:TAG_9F03];
    [array addObject:TAG_9F34];
    [array addObject:TAG_9F12];
    [array addObject:TAG_9F06];
    [array addObject:TAG_5F30];
    [array addObject:TAG_9F4E];
    [array addObject:TAG_C4];
    [array addObject:TAG_C1];
    [array addObject:TAG_C7];
    [array addObject:TAG_C0];
    //[array addObject:TAG_C2];
    return array;
}

-(NSMutableArray*)getArrayTagQposC{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getArrayTagQpos");
    NSMutableArray* array = [[NSMutableArray alloc]init];
    [array addObject:TAG_C4];
    [array addObject:TAG_C1];
    [array addObject:TAG_C7];
    [array addObject:TAG_C0];
    //[array addObject:TAG_C2];
    return array;
}


-(NSMutableArray*)getArrayTagQposNew{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getArrayTagQposNew");
    NSMutableArray* array = [[NSMutableArray alloc]init];
    [array addObject:TAG_5F20];
    [array addObject:TAG_4F];
    [array addObject:TAG_5F24];
    [array addObject:TAG_9F16];
    [array addObject:TAG_9F21];
    [array addObject:TAG_9A];
    [array addObject:TAG_9F02];
    [array addObject:TAG_9F03];
    [array addObject:TAG_9F34];
    [array addObject:TAG_9F12];
    [array addObject:TAG_9F06];
    [array addObject:TAG_5F30];
    [array addObject:TAG_9F4E];
    return array;
}

-(NSString*) hexToString: (NSString*)str{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: hexToString");
    NSMutableString * newString = [[NSMutableString alloc] init];
    int i = 0;
    NSLog(@"hexToString str %@:",str);
    if([str length] % 2 != 0){
        return str;
    }
    while (i < [str length])
    {
        NSLog(@"hexToString str %@:",str);
        NSString * hexChar = [str substringWithRange: NSMakeRange(i, 2)];
        int value = 0;
        sscanf([hexChar cStringUsingEncoding:NSASCIIStringEncoding], "%x", &value);
        [newString appendFormat:@"%c", (char)value];
        i+=2;
    }
    return newString;
}
-(NSString*) getTypeCardEmv: (NSString*) aid: (NSString*) label{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getTypeCardEmv");
    NSString* typecard=DEBITO;
    if ([aid isEqualToString: nil] || [aid isEqualToString: @""]) {
        return @"";
    }
    hexLabel = [self hexToString:label];
    hexLabel = [hexLabel uppercaseString];
    NSLog(@"hexToString hexLabel %@:",hexLabel);
    NSRange range = [hexLabel rangeOfString:AID_LABEL_DEBIT];
    bool debitLabelFound=(range.location != NSNotFound);
    NSLog(@"QPOS_PLUGIN_NATIVE_I: debitLabelFound", debitLabelFound ? @"YES" : @"NO");
    if([aid isEqualToString:(AID_MAESTRO)] ||
       [aid isEqualToString:(AID_VISA_ELECTRON)] ||
       ([aid isEqualToString:(AID_MASTERCARD)] && (debitLabelFound)) ||
       ([aid isEqualToString:(AID_VISA_CREDITO)] && (debitLabelFound))
       ){
    NSLog(@"QPOS_PLUGIN_NATIVE_I: ENTRO ESTA CACORRADA", debitLabelFound ? @"YES" : @"NO");
        typecard = DEBITO;
    }else{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: NO ENTRO ESTA CACORRADA", debitLabelFound ? @"YES" : @"NO");
        typecard = CREDITO;
    }
    
    return typecard;
}
-(NSString*) getFranquisieCardEmv:(NSString*) aid{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getFranquisieCardEmv");
    if ([aid isEqualToString:AID_MAESTRO]) {
        return MAESTRO;
    }
    if([aid isEqualToString:AID_VISA_ELECTRON]) {
        return VISA_ELECTRON;
    }
    if([aid isEqualToString:AID_MASTERCARD]) {
        return MASTERCARD;
    }
    if([aid isEqualToString:AID_VISA_CREDITO]){
        return VISA_CREDITO;
    }
    return @"";
}
-(NSMutableDictionary*) getTrack2Data:(NSString*) data{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getTrack2Data");
    
    NSString* ksn = [data substringWithRange:NSMakeRange(4, 20)];
    NSString* track2_enc = [data substringFromIndex:28];
    return [NSMutableDictionary dictionaryWithObjectsAndKeys:
            ksn, @"ksn",
            track2_enc, @"track2_enc",
            nil];
}
// ARREGLO PARA CONTAT LESS DEL TRACK 2 QUE LLEGA MAS LARGO
-(NSMutableDictionary*) getTrack2DataCless:(NSString*) data{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getTrack2Data");
    
    NSString* ksn = [data substringWithRange:NSMakeRange(4, 20)];
    NSString* track2_enc = [data substringWithRange:NSMakeRange(28, 48)];
    // NSString* track2_enc = [data substringFromIndex:28];
    return [NSMutableDictionary dictionaryWithObjectsAndKeys:
            ksn, @"ksn",
            track2_enc, @"track2_enc",
            nil];
}
- (NSData*)readLine:(NSString*)name
{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: readLine");
    NSString* binFile = [[NSBundle mainBundle]pathForResource:name ofType:@".bin"];
    NSString* ascFile = [[NSBundle mainBundle]pathForResource:name ofType:@".asc"];
    NSLog(@"[%@]-- [%@]",name,ascFile);
    if (binFile!= nil && ![binFile isEqualToString: @""]) {
        NSFileManager* Manager = [NSFileManager defaultManager];
        NSData* data1 = [[NSData alloc] init];
        data1 = [Manager contentsAtPath:binFile];
        NSLog(@"BIN----------");
        return data1;
    }else if (ascFile!= nil && ![ascFile isEqualToString: @""]){
        NSFileManager* Manager = [NSFileManager defaultManager];
        NSData* data2 = [[NSData alloc] init];
        data2 = [Manager contentsAtPath:ascFile];
        NSLog(@"ASC----------");
        return data2;
    }
    return nil;
}
//--------------------------------------------------------------------------------------------------------------------------------------------
//TRANSACCTIONS-------------------------------------------------------------------------------------------------------------------------------
-(void)startTransaccion: (NSString*) amount_par{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: startTransaccion");
    NSLog(@"+++QPOS PLUGIN startTransaccion+++ amount+++:%@",amount_par);
    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    [dateFormatter setDateFormat:@"yyyyMMddHHmmss"];
    _terminalTime = [dateFormatter stringFromDate:[NSDate date]];
    mTransType = TransactionType_GOODS;
    amount_par = [NSString stringWithFormat:@"%@",amount_par];
    amount = [amount_par stringByAppendingString:CENTS];
    _currencyCode = CURRENCY_TYPE;
    typeCardEntry=@"";
    isSelectApp=NO;
    stateTx = DECLINE;
    //[mQPOSService setDoTradeMode:DoTradeMode_CHECK_CARD_NO_IPNUT_PIN];
    [mQPOSService setOnlineTime:300];
    [mQPOSService setCardTradeMode:CardTradeMode_SWIPE_TAP_INSERT_CARD];
    [mQPOSService doCheckCard:30];
}
-(void)getDataTransaccion{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getDataTransaccion");
    NSString *jsonString= @"";
    object =nil;
    BOOL valid = YES;
    if([stateTx isEqualToString:WAITING_USER_STATE]){
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  WAITING_USER_STATE, @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        jsonString = [self convertDictionaryToString: object];
    }else if([stateTx isEqualToString:PLEASE_WAIT_STATE]){
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  PLEASE_WAIT_STATE, @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        jsonString = [self convertDictionaryToString: object];
    }else if([stateTx isEqualToString:PROCESSING_STATE]){
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  PROCESSING_STATE, @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        jsonString = [self convertDictionaryToString: object];
    }else if([stateTx isEqualToString:GET_PIN_STATE]){
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  GET_PIN_STATE, @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        jsonString = [self convertDictionaryToString: object];
    }else if([stateTx isEqualToString:APPROVAL]){
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  APPROVAL, @"code",
                  @"success", @"message",
                  cardInfo, @"data",
                  nil];
        jsonString = [self convertDictionaryToString: object];
    }else if([stateTx isEqualToString:FALLBACK]){
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  FALLBACK, @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        jsonString = [self convertDictionaryToString: object];
    }else if([stateTx isEqualToString:SELECT_APP]){
        stateTx = SELECTED_APP;
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  SELECT_APP, @"code",
                  @"success", @"message",
                  listApp, @"data",
                  nil];
        jsonString = [self convertDictionaryToString: object];
    }else if([stateTx isEqualToString:SELECTED_APP]){
        stateTx = PROCESSING_STATE;
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  stateTx, @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        jsonString = [self convertDictionaryToString: object];
        NSInteger pos = [ [commandLocal.arguments objectAtIndex:0] intValue];
        NSLog(@"+++QPOS PLUGIN app seleccionada+++:%d",pos);
        [mQPOSService selectEmvApp:pos];
    }else if([stateTx isEqualToString:ERROR_SWIPE_CHIP]){
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  stateTx, @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        jsonString = [self convertDictionaryToString: object];
    } else if ([stateTx isEqualToString:GET_SWIPE_PIN]) {
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  stateTx, @"code",
                  @"Obteniendo pin tarjeta", @"message",
                  nil, @"data",
                  nil];
        jsonString = [self convertDictionaryToString: object];
    }
    else{
        valid = NO;
        jsonString = @"";
    }
    if(valid){
        if (![stateTx isEqualToString:GET_SWIPE_PIN]) {
            CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:jsonString]];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
        }
    }else{
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:jsonString]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }
}
-(void)onRequestSetAmount{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestSetAmount");
    NSLog(@"+++QPOS PLUGIN onRequestSetAmount+++ amount:%@",amount);
    
    [mQPOSService setAmount:amount aAmountDescribe:CASHBACK_AMOUNT currency:CURRENCY_TYPE transactionType:TransactionType_GOODS];
}
-(void)onRequestSelectEmvApp:(NSArray *)appList{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestSelectEmvApp");
    NSLog(@"+++QPOS PLUGIN onRequestSelectEmvApp+++%@",appList);
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:appList options:NSJSONWritingPrettyPrinted error:&error];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    listApp = jsonString;
    stateTx = SELECT_APP;
    isSelectApp = YES;
}
-(void)getSwipePin:(NSString *)maskedPan{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getSwipePin");
    NSLog(@"+++QPOS PLUGIN getSwipePin+++%@",maskedPan);
    //[mQPOSService resetPosStatus];
    flagPinSwipe = YES;
    stateTx = GET_SWIPE_PIN;
    [mQPOSService setCardTradeMode:CardTradeMode_ONLY_SWIPE_CARD];
    //Done by Jose Quintero, fix sodexo
    [mQPOSService setDoTradeMode:DoTradeMode_COMMON];
    [mQPOSService doTrade: 30];
}
-(void)onRequestWaitingUser{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestWaitingUser");
    NSLog(@"+++QPOS PLUGIN onRequestWaitingUser+++");
    object =nil;
    if (![stateTx isEqualToString:ERROR_SWIPE_CHIP] && ![stateTx isEqualToString:GET_SWIPE_PIN]) {
        if ([typeCardEntry isEqualToString:FALLBACK]) {
            stateTx = FALLBACK;
        } else {
            stateTx = WAITING_USER_STATE;
        }
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  stateTx, @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK
                                                          messageAsString:[NSString stringWithFormat:[self convertDictionaryToString: object]]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }
}
-(NSMutableDictionary*) getDataTransactionSwipeBand: (NSDictionary*)decodeData{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getDataTransactionSwipeBand");
    NSLog(@"decodeData: %@",decodeData);
    NSString *formatID = [NSString stringWithFormat:@"%@",decodeData[@"formatID"]] ;
    NSString *maskedPAN = [NSString stringWithFormat:@"%@",decodeData[@"maskedPAN"]];
    NSString *lastfour = [maskedPAN substringFromIndex:maskedPAN.length-4];
    NSInteger len = [maskedPAN length];
    maskedPAN = [maskedPAN substringWithRange:NSMakeRange(0, 8)];
    maskedPAN = [maskedPAN stringByAppendingString:@"****"];
    maskedPAN = [maskedPAN stringByAppendingString:lastfour];
    NSString *expiryDate = [NSString stringWithFormat:@"%@",decodeData[@"expiryDate"]];
    NSString *cardHolderName = [NSString stringWithFormat:@"%@",decodeData[@"cardholderName"]];
    NSString *serviceCode = [NSString stringWithFormat:@"%@",decodeData[@"serviceCode"]];
    NSString *encTrack1 = [NSString stringWithFormat:@"%@",decodeData[@"encTrack1"]];
    NSString *encTrack2 = [NSString stringWithFormat:@"%@",decodeData[@"encTrack2"]];
    NSString *encTrack3 = [NSString stringWithFormat:@"%@",decodeData[@"encTrack3"]];
    NSString *pinKsn = [NSString stringWithFormat:@"%@",decodeData[@"pinKsn"]];
    NSString *trackksn = [NSString stringWithFormat:@"%@",decodeData[@"trackksn"]];
    NSString *pinBlock = [NSString stringWithFormat:@"%@",decodeData[@"pinblock"]];
    NSString *encPAN = [NSString stringWithFormat:@"%@",decodeData[@"encPAN"]];
    isBanda = YES;
    NSString *firstOne = [serviceCode substringToIndex:1];
    if ([firstOne isEqualToString:@"2"] || [firstOne isEqualToString:@"6"]) {
        isChip = YES;
    } else {
        isChip = NO;
    }
    NSString *bin = [[NSString stringWithFormat:@"%@",decodeData[@"maskedPAN"]] substringWithRange:NSMakeRange(0, 8)];
    if ([bin isEqualToString:@"880001"]) {
        isChip = NO;
    }
    isFallback = NO;
    tipoCuentaId =@"";
    posEntryMode = BAND;
    tipoEntrada = MODE_MAGNETIC_SWIPE;
    
    object=nil;
    if (isChip) {
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  cardHolderName, @"tarjetaHabiente",
                  expiryDate, @"fechaExp",
                  trackksn, @"ksn",
                  pinKsn, @"ksnPinBlock",
                  maskedPAN, @"panEnmascarado",
                  maskedPAN, @"pan",
                  encTrack2, @"track2",
                  @(isBanda), @"isBanda",
                  @"YES", @"isChip",
                  posEntryMode, @"PosEntryMode",
                  pinBlock,@"pinBlock",
                  tipoCuentaId,@"tipoCuentaId",
                  lastfour,@"ultimosCuatro",
                  @"",@"franquicia",
                  [NSNumber numberWithInt:tipoEntrada],@"tipoEntrada",
                  @(isFallback),@"fallback",
                  @"",@"aid",
                  @"",@"tagVenta",
                  @"",@"arqc",
                  nil];
    } else {
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  cardHolderName, @"tarjetaHabiente",
                  expiryDate, @"fechaExp",
                  trackksn, @"ksn",
                  pinKsn, @"ksnPinBlock",
                  maskedPAN, @"panEnmascarado",
                  maskedPAN, @"pan",
                  encTrack2, @"track2",
                  @(isBanda), @"isBanda",
                  @"NO", @"isChip",
                  posEntryMode, @"PosEntryMode",
                  pinBlock,@"pinBlock",
                  tipoCuentaId,@"tipoCuentaId",
                  lastfour,@"ultimosCuatro",
                  @"",@"franquicia",
                  [NSNumber numberWithInt:tipoEntrada],@"tipoEntrada",
                  @(isFallback),@"fallback",
                  @"",@"aid",
                  @"",@"tagVenta",
                  @"",@"arqc",
                  nil];
    }
    
    //NSString* jsonString = [self convertDictionaryToString:object];
    NSLog(@"decodeData: %@",object);
    return object;
    
}
-(NSString*) getDataTransactionFallback: (NSDictionary*)decodeData{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getDataTransactionFallback");
    NSLog(@"decodeData: %@",decodeData);
    NSString *formatID = [NSString stringWithFormat:@"%@",decodeData[@"formatID"]] ;
    NSString *maskedPAN = [NSString stringWithFormat:@"%@",decodeData[@"maskedPAN"]];
    NSString *lastfour = [maskedPAN substringFromIndex:maskedPAN.length-4];
    maskedPAN = [maskedPAN substringWithRange:NSMakeRange(0, 8)];
    maskedPAN = [maskedPAN stringByAppendingString:@"****"];
    maskedPAN = [maskedPAN stringByAppendingString:lastfour];
    NSString *expiryDate = [NSString stringWithFormat:@"%@",decodeData[@"expiryDate"]];
    NSString *cardHolderName = [NSString stringWithFormat:@"%@",decodeData[@"cardholderName"]];
    NSString *serviceCode = [NSString stringWithFormat:@"%@",decodeData[@"serviceCode"]];
    NSString *encTrack1 = [NSString stringWithFormat:@"%@",decodeData[@"encTrack1"]];
    NSString *encTrack2 = [NSString stringWithFormat:@"%@",decodeData[@"encTrack2"]];
    NSString *encTrack3 = [NSString stringWithFormat:@"%@",decodeData[@"encTrack3"]];
    NSString *pinKsn = [NSString stringWithFormat:@"%@",decodeData[@"pinKsn"]];
    NSString *trackksn = [NSString stringWithFormat:@"%@",decodeData[@"trackksn"]];
    NSString *pinBlock = [NSString stringWithFormat:@"%@",decodeData[@"pinblock"]];
    NSString *encPAN = [NSString stringWithFormat:@"%@",decodeData[@"encPAN"]];
    isBanda = YES;
    isChip = NO;
    isFallback = YES;
    tipoCuentaId =@"";
    posEntryMode = FALL_BACK;
    tipoEntrada = MODE_MAGNETIC_SWIPE;
    
    object=nil;
    object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
              cardHolderName, @"tarjetaHabiente",
              expiryDate, @"fechaExp",
              trackksn, @"ksn",
              pinKsn, @"ksnPinBlock",
              maskedPAN, @"panEnmascarado",
              maskedPAN, @"pan",
              encTrack2, @"track2",
              @(isBanda), @"isBanda",
              @(isChip), @"isChip",
              posEntryMode, @"PosEntryMode",
              pinBlock,@"pinBlock",
              tipoCuentaId,@"tipoCuentaId",
              lastfour,@"ultimosCuatro",
              @"",@"franquicia",
              [NSNumber numberWithInt:tipoEntrada],@"tipoEntrada",
              @(isFallback),@"fallback",
              @"",@"aid",
              @"",@"tagVenta",
              @"",@"arqc",
              nil];
    return [self convertDictionaryToString:object];
    
}
-(NSString*) getDataTransactionContactless: (NSDictionary*)decodeData: (NSDictionary*)nfcBashData: (NSString*)hashtableTrack2: (NSString*)hashtableAid: (NSString*)hashtableARQC: (NSString*)hashtableTrack2Plain: (NSString*)hashtableLabel: (NSString*)tagSale{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getDataTransactionContactless");
    NSLog(@"decodeData: %@",decodeData);
    
    NSString* jsonString;
    
    NSString *formatID = decodeData[@"formatID"] ;
    NSString *maskedPAN = nil;
    NSString *expiryDate = nil;
    NSString *cardHolderName = nil;
    NSString *serviceCode = nil;
    NSString *trackblock = nil;
    NSString *psamId = nil;
    NSString *posId = nil;
    NSString *pinBlock = nil;
    NSString *macblock = nil;
    NSString *activateCode = nil;
    NSString *tackRandomNumber = nil;
    NSString *track1Length = nil;
    NSString *track2Length = nil;
    NSString *track3Length = nil;
    NSString *encTracks = nil;
    NSString *encTrack1 = nil;
    NSString *encTrack2 = nil;
    NSString *encTrack3 = nil;
    NSString *partialTrack = nil;
    NSString *pinKsn = nil;
    NSString *trackksn = nil;
    NSString *encPAN = nil;
    NSString *pinRandomNumber = nil;
    if ([formatID isEqualToString:@"31"] || [formatID isEqualToString:@"40"] || [formatID isEqualToString:@"37"] || [formatID isEqualToString:@"17"] ||[formatID isEqualToString:@"11"] || [formatID isEqualToString:@"10"]) {
        maskedPAN = decodeData[@"maskedPAN"];
        expiryDate = decodeData[@"expiryDate"];
        cardHolderName = decodeData[@"cardholderName"];
        serviceCode = decodeData[@"serviceCode"];
        trackblock = decodeData[@"trackblock"];
        psamId = decodeData[@"psamId"];
        posId = decodeData[@"posId"];
        pinBlock = decodeData[@"pinblock"];
        macblock = decodeData[@"macblock"];
        activateCode = decodeData[@"activateCode"];
        tackRandomNumber = decodeData[@"tackRandomNumber"];
    } else {
        maskedPAN = decodeData[@"maskedPAN"];
        expiryDate = decodeData[@"expiryDate"];
        cardHolderName = decodeData[@"cardholderName"];
        serviceCode = decodeData[@"serviceCode"];
        track1Length = decodeData[@"track1Length"];
        track2Length = decodeData[@"track2Length"];
        track3Length = decodeData[@"track3Length"];
        encTracks = decodeData[@"encTracks"];
        encTrack1 = decodeData[@"encTrack1"];
        encTrack2 = decodeData[@"encTrack2"];
        encTrack3 = decodeData[@"encTrack3"];
        partialTrack = decodeData[@"partialTrack"];
        pinKsn = decodeData[@"pinKsn"];
        trackksn = decodeData[@"trackksn"];
        pinBlock = decodeData[@"pinblock"];
        encPAN = decodeData[@"encPAN"];
        tackRandomNumber = decodeData[@"tackRandomNumber"];
        pinRandomNumber = decodeData[@"pinRandomNumber"];
    }
    
    NSString *pan = @"";
    pan = maskedPAN;
    NSString *lastfour = [pan substringFromIndex:pan.length-4];
    pan = [pan substringToIndex:8];
    pan = [pan stringByAppendingString:@"****"];
    pan = [pan stringByAppendingString:lastfour];
    
    NSString *tarjetaHabiente = [mQPOSService getICCTag:EncryptType_plaintext cardType:1 tagCount:1 tagArrStr:TAG_5F20][@"tlv"];
    if(![tarjetaHabiente isEqualToString:@""]){
        tarjetaHabiente = [tarjetaHabiente substringFromIndex:6];
        tarjetaHabiente = [self hexToString:tarjetaHabiente];
    }
    
    tipoCuentaId = DEBITO;//[self getTypeCardEmv:aid :label];
    NSString* franquicia = [self getFranquisieCardEmv:hashtableAid];
    NSString* posEntrymode;
    NSString* track2_enc;
    NSString* ksn;
    NSString* tagVenta = @"";
    if(![hashtableARQC isEqualToString:@""]) {
        track2_enc = [self getTrack2Data:hashtableTrack2][@"track2_enc"];
        ksn = [self getTrack2Data:hashtableTrack2][@"ksn"];
        posEntrymode = CONTACTLESS_CHIP;
        tagVenta = tagSale;
    } else {
        track2_enc = encTrack2;
        ksn = trackksn;
        posEntrymode = CONTACTLESS_BAND;
    }
    
    NSMutableDictionary *objectCard =nil;
    objectCard = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  hashtableAid,@"aid",
                  hashtableARQC,@"arqc",
                  @(NO), @"isBanda",
                  @(NO), @"isChip",
                  @(NO),@"fallback",
                  expiryDate, @"fechaExp",
                  franquicia,@"franquicia",
                  trackksn, @"ksn",
                  pinKsn, @"ksnPinBlock",
                  trackksn, @"ksnTrackII",
                  pan, @"pan",
                  pan, @"panEnmascarado",
                  pinBlock,@"pinBlock",
                  tipoCuentaId,@"tipoCuentaId",
                  CONTACTLESS_CHIP,@"PosEntryMode",
                  tagVenta,@"tagVenta",
                  tarjetaHabiente, @"tarjetaHabiente",
                  [NSNumber numberWithInt:MODE_CONTACTLESS],@"tipoEntrada",
                  @"", "track1",
                  encTrack1, "track1Cifrado",
                  @"", "track2",
                  encTrack2, "track2Cifrado",
                  encTrack3, "track3",
                  lastfour, @"ultimosCuatro",
                  nil];
    
    return [self convertDictionaryToString:objectCard];
}
-(void) onDoTradeResult: (DoTradeResult)result DecodeData:(NSDictionary*)decodeData{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onDoTradeResult");
    NSLog(@"+++QPOS PLUGIN onDoTradeResult+++");
    NSLog(@"onDoTradeResult?>> result %ld",(long)result);
    
    flagPinSwipe = NO;
    if (result==DoTradeResult_MCR) {
        //se lee tarjeta banda
        cardInfo = nil;
        if ([typeCardEntry isEqualToString:FALLBACK]) {
            stateTx = PROCESSING_STATE;
            cardInfo = [self getDataTransactionFallback:decodeData];
            object = nil;
            object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                      SUCCESFUL, @"code",
                      @"success", @"message",
                      cardInfo, @"data",
                      nil];
            stateTx = APPROVAL;
            NSString *jsonString = [self convertDictionaryToString:object];
            pinStringFirstResponse = jsonString;
            CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:pinStringFirstResponse]];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
        } else {
            stateTx = PROCESSING_STATE;
            typeCardEntry = BAND;
            NSMutableDictionary* cardInfoObj = [self getDataTransactionSwipeBand:decodeData];
            cardInfo = [self convertDictionaryToString:cardInfoObj];
            NSLog(@"decodeData: %@",cardInfoObj);
            if([cardInfoObj[@"isChip"] isEqualToString:@"YES"]){
                stateTx = ERROR_SWIPE_CHIP;
                [mQPOSService doCheckCard:30];
            }else{
                stateTx = APPROVAL;
                object = nil;
                object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                          SUCCESFUL, @"code",
                          @"success", @"message",
                          cardInfo, @"data",
                          nil];
                NSString *jsonString = [self convertDictionaryToString:object];
                pinStringFirstResponse = jsonString;
                CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:pinStringFirstResponse]];
                [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
            }
        }
    } else if (result == DoTradeResult_ICC) {
        //Se lee tarjeta EMV
        typeCardEntry = CHIP;
        [mQPOSService doEmvApp:EmvOption_START];
    } else if (result == DoTradeResult_NOT_ICC){
        typeCardEntry = FALL_BACK;
        [mQPOSService setCardTradeMode:CardTradeMode_ONLY_SWIPE_CARD];
        [mQPOSService doCheckCard:30];
    } else if (result == DoTradeResult_NONE) {
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if (result == DoTradeResult_BAD_SWIPE) {
        
    } else if (result == DoTradeResult_NFC_ONLINE || result == DoTradeResult_NFC_OFFLINE) {
        NSString *track2 = [mQPOSService getICCTag:EncryptType_encrypted cardType:1 tagCount:1 tagArrStr:TAG_57][@"tlv"];
        NSString *track2_plain = [mQPOSService getICCTag:EncryptType_plaintext cardType:1 tagCount:1 tagArrStr:TAG_57][@"tlv"];
        NSDictionary* tlvTag;
        NSString* jsonString;
        NSString* tagSale=@"";
        NSMutableArray* tagSalesArray = [self getArrayTagSales];
        NSString* tag;
        for(NSInteger i = 0 ; i < [tagSalesArray count] ; i++){
            tag = [tagSalesArray objectAtIndex:i];
            tlvTag = [mQPOSService getICCTag:EncryptType_plaintext cardType:1 tagCount:1 tagArrStr:tag];
            if([tag isEqualToString:TAG_9F03] ){
                tagSale = [tagSale stringByAppendingString:@"9F0306000000000000"];
            }else{
                tagSale = [tagSale stringByAppendingString:tlvTag[@"tlv"]];
            }
        }
        dispatch_async(dispatch_get_main_queue(),  ^{
            NSDictionary *mDic = [mQPOSService getNFCBatchData];
            NSString *tlv;
            if(mDic !=nil){
                tlv= [NSString stringWithFormat:@"NFCBatchData: %@\n",mDic[@"tlv"]];
                NSLog(@"--------nfc:tlv%@",tlv);
            }else{
                tlv = @"";
            }
        });
        
        NSString *formatID = decodeData[@"formatID"] ;
        NSString *maskedPAN = decodeData[@"maskedPAN"];
        NSString *expiryDate = decodeData[@"expiryDate"];
        NSString *cardHolderName = decodeData[@"cardholderName"];
        NSString *serviceCode = decodeData[@"serviceCode"];
        NSString *encTrack1 = decodeData[@"encTrack1"];
        NSString *encTrack2 = decodeData[@"encTrack2"];
        NSString *encTrack3 = decodeData[@"encTrack3"];
        //NSString *partialTrack = [NSString stringWithFormat:@"Partial Track: %@",decodeData[@"partialTrack"]];
        NSString *pinKsn = decodeData[@"pinKsn"];
        NSString *trackksn = decodeData[@"trackksn"];
        NSString *pinBlock = decodeData[@"pinblock"];
        NSString *encPAN = decodeData[@"encPAN"];
        
        NSString *pan = @"";
        pan = maskedPAN;
        NSString *lastfour = [pan substringFromIndex:pan.length-4];
        pan = [pan substringToIndex:8];
        pan = [pan stringByAppendingString:@"****"];
        pan = [pan stringByAppendingString:lastfour];
        
        NSString *tarjetaHabiente = [mQPOSService getICCTag:EncryptType_plaintext cardType:1 tagCount:1 tagArrStr:TAG_5F20][@"tlv"];
        if(![tarjetaHabiente isEqualToString:@""]){
            tarjetaHabiente = [tarjetaHabiente substringFromIndex:6];
            tarjetaHabiente = [self hexToString:tarjetaHabiente];
        }
        NSString *fechaExp = expiryDate;
        
        NSString *label = [mQPOSService getICCTag:EncryptType_plaintext cardType:1 tagCount:1 tagArrStr:TAG_9F12][@"tlv"];
        if(![label isEqualToString:@""]){
            label = [label substringFromIndex:6];
        }
        NSString *arqc = [mQPOSService getICCTag:EncryptType_plaintext cardType:1 tagCount:1 tagArrStr:TAG_9F26][@"tlv"];
        if(![arqc isEqualToString:@""]){
            arqc = [arqc substringFromIndex:6];
        }
        NSString *aid = [mQPOSService getICCTag:EncryptType_plaintext cardType:1 tagCount:1 tagArrStr:TAG_84][@"tlv"];
        if(![aid isEqualToString:@""] && ![aid isEqualToString:@"8400"]){
            aid = [aid substringFromIndex:4];
        } else {
            aid = [mQPOSService getICCTag:EncryptType_plaintext cardType:1 tagCount:1 tagArrStr:TAG_9F06][@"tlv"];
            if (![aid isEqualToString:@""]) {
                aid = [aid substringFromIndex:6];
            }
        }
        tipoCuentaId = [self getTypeCardEmv:aid :label];
        NSLog(@" tipoCuentaIdUJU %@:",tipoCuentaId);
        NSString* franquicia = [self getFranquisieCardEmv:aid];
        NSString* posEntrymode;
        NSString*track2_enc;
        NSString*ksn;
        if(![arqc isEqualToString:@""]){
            track2_enc = [self getTrack2DataCless:track2][@"track2_enc"];
            ksn = [self getTrack2Data:track2][@"ksn"];
            posEntrymode = CONTACTLESS_CHIP;
        }else{
            track2_enc = encTrack2;
            ksn = trackksn;
            posEntrymode = CONTACTLESS_BAND;
        }
        NSLog(@" pinBLOCK %@:",pinBlock);
        NSLog(@" ksn pinblock %@:",pinKsn);
        NSLog(@" arqc %@:",arqc);
        NSLog(@" track2 %@:",track2);
        NSLog(@" pan %@:",pan);
        NSLog(@" aid %@:",aid);
        NSLog(@" tarjetaHabiente %@:",tarjetaHabiente);
        NSLog(@" fechaExp %@:",fechaExp);
        NSLog(@" label %@:",label);
        NSLog(@" apLabel %@:",hexLabel);
        NSLog(@" track2_plain %@:",track2_plain);
        NSLog(@" track2 %@:",track2_plain);
        NSLog(@" aid %@:",aid);
        NSMutableDictionary *objectCard =nil;
        // objectCard = [NSMutableDictionary dictionaryWithObjectsAndKeys:
        //             tipoCuentaId,@"tipoCuentaId",
        //             tarjetaHabiente, @"tarjetaHabiente",
        //             fechaExp, @"fechaExp",
        //             ksn, @"ksn",
        //             pinKsn, @"ksnPinBlock",
        //             pan, @"panEnmascarado",
        //             pan, @"pan",
        //             track2_enc, @"track2",
        //             @(NO), @"isBanda",
        //             @(NO), @"isChip",
        //             CONTACTLESS_CHIP, @"PosEntryMode",
        //             pinBlock,@"pinBlock",
        //             lastfour,@"ultimosCuatro",
        //             franquicia,@"franquicia",
        //             [NSNumber numberWithInt:MODE_CONTACTLESS],@"tipoEntrada",
        //             @(NO),@"fallback",
        //             aid,@"aid",
        //             tagSale,@"tagVenta",
        //             arqc,@"arqc",
        //             nil];
        // NSLog(@"onRequestOnlineProcess objectCard: %@",objectCard);
        // cardInfo = [self convertDictionaryToString: objectCard];
        // object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
        //         SUCCESFUL, @"code",
        //         @"success", @"message",
        //         cardInfo, @"data",
        //         nil];
        // NSLog(@"onRequestOnlineProcess: %@",object);
        // stateTx = APPROVAL;
        // jsonString = [self convertDictionaryToString: object];
        // CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:jsonString]];
        // [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];

        objectCard = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                      tipoCuentaId,@"tipoCuentaId",
                      tagSale,@"tagVenta",
                      franquicia,@"franquicia",
                      arqc,@"arqc",
                      aid,@"aid",
                      tarjetaHabiente, @"tarjetaHabiente",
                      fechaExp, @"fechaExp",
                      ksn, @"ksn",
                      pinKsn, @"ksnPinBlock",
                      pan, @"panEnmascarado",
                      pan, @"pan",
                      track2_enc, @"track2",
                      @(NO), @"isBanda",
                      @(NO), @"isChip",
                      CONTACTLESS_CHIP, @"PosEntryMode",
                      pinBlock,@"pinBlock",
                      lastfour,@"ultimosCuatro",
                      [NSNumber numberWithInt:MODE_CONTACTLESS],@"tipoEntrada",
                      @(NO),@"fallback",
                      nil];

        // objectCard = [NSMutableDictionary dictionaryWithObjectsAndKeys:
        //               tipoCuentaId,@"tipoCuentaId",
        //               tarjetaHabiente, @"tarjetaHabiente",
        //               fechaExp, @"fechaExp",
        //               ksn, @"ksn",
        //               pinKsn, @"ksnPinBlock",
        //               pan, @"panEnmascarado",
        //               pan, @"pan",
        //               track2_enc, @"track2",
        //               @(NO), @"isBanda",
        //               @(NO), @"isChip",
        //               CONTACTLESS_CHIP, @"PosEntryMode",
        //               pinBlock,@"pinBlock",
        //               lastfour,@"ultimosCuatro",
        //               franquicia,@"franquicia",
        //               [NSNumber numberWithInt:MODE_CONTACTLESS],@"tipoEntrada",
        //               @(NO),@"fallback",
        //               aid,@"aid",
        //               tagSale,@"tagVenta",
        //               arqc,@"arqc",
        //               nil];
        NSLog(@"onRequestOnlineProcess objectCard: %@",objectCard);
        cardInfo = [self convertDictionaryToString: objectCard];
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  SUCCESFUL, @"code",
                  @"success", @"message",
                  cardInfo, @"data",
                  nil];
        NSLog(@"onRequestOnlineProcess: %@",object);
        stateTx = APPROVAL;
        jsonString = [self convertDictionaryToString: object];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:jsonString]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if (result == DoTradeResult_NFC_DECLINED) {
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@"NFC declinada"]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else {
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }
}
-(void) onRequestTime{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestTime");
    NSLog(@"+++QPOS PLUGIN onRequestTime+++");
    //    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    //    [dateFormatter setDateFormat:@"yyyyMMddHHmmss"];
    //    NSString *terminalTime = [dateFormatter stringFromDate:[NSDate date]];
    //NSDateFormatter *dateFormatter = [NSDateFormatter new];
    //[dateFormatter setDateFormat:@"yyyyMMddHHmmss"];
    //_terminalTime = [dateFormatter stringFromDate:[NSDate date]];
    [mQPOSService sendTime:_terminalTime];
    
}
-(void) onRequestDisplay: (Display)displayMsg{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestDisplay");
    NSLog(@"+++QPOS PLUGIN onRequestDisplay+++");
    NSString *jsonString= @"";
    //NSString *mensaje = @"";
    object =nil;
    BOOL valid = YES;
    if(displayMsg == Display_PROCESSING){
        if (!flagPinSwipe) {
            stateTx = PROCESSING_STATE;
            //mensaje = @"Procesando..";
        }
    }else if(displayMsg == Display_INPUT_PIN_ING){
        if (!flagPinSwipe) {
            stateTx = GET_PIN_STATE;
            //mensaje = @"Por favor, Digite el pin.";
        }
    }else if(displayMsg == Display_PLEASE_WAIT){
        if (!flagPinSwipe) {
            stateTx = PLEASE_WAIT_STATE;
            //mensaje = @"Por favor espere.";
        }
    }else if(displayMsg == Display_TRANSACTION_TERMINATED){
        valid = NO;
        stateTx = DECLINE;
    }
    object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
              stateTx, @"code",
              @"success", @"message",
              nil, @"data",
              nil];
    jsonString = [self convertDictionaryToString: object];
    if(valid){
        if (!flagPinSwipe) {
            CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:jsonString]];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
        }
    }else{
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:jsonString]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }
}

-(void) onReturnGetPinResult:(NSDictionary*)decodeData{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onReturnGetPinResult");
    NSLog(@"onRequestOnlineProcess decodeData: %@",decodeData);
    NSString *ksnPinBlock = decodeData[@"pinKsn"];
    NSString *pinblock = decodeData[@"pinBlock"];
    NSMutableDictionary *objectCard =nil;
    NSString* jsonString;
    
    objectCard = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  @"", @"tarjetaHabiente",
                  @"", @"fechaExp",
                  @"", @"ksn",
                  ksnPinBlock, @"ksnPinBlock",
                  @"", @"panEnmascarado",
                  @"", @"pan",
                  @"", @"track2",
                  @(YES), @"isBanda",
                  @(NO), @"isChip",
                  @"", @"PosEntryMode",
                  pinblock,@"pinBlock",
                  @"",@"tipoCuentaId",
                  @"",@"ultimosCuatro",
                  @"",@"franquicia",
                  @"",@"tipoEntrada",
                  @(NO),@"fallback",
                  @"",@"aid",
                  @"",@"tagVenta",
                  @"",@"arqc",
                  nil];
    cardInfo = [self convertDictionaryToString: objectCard];
    
    object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
              SUCCESFUL, @"code",
              @"success", @"message",
              cardInfo, @"data",
              nil];
    NSLog(@"onRequestOnlineProcess: %@",object);
    //stateTx = APPROVAL;
    jsonString = [self convertDictionaryToString: object];
    NSLog(@"onRequestOnlineProcess jsonString: %@",jsonString);
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:jsonString]];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    
}
-(void) onRequestOnlineProcess: (NSString*) tlv{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestOnlineProcess");
    NSLog(@"+++QPOS PLUGIN onRequestOnlineProcess+++ %@:",tlv);
    stateTx = PROCESSING_STATE;
    NSMutableDictionary *objectCard =nil;
    NSString* jsonString;
    NSDictionary* tlvTag;
    NSString* tagSale=@"";
    NSMutableArray* tagSalesArray = [self getArrayTagSales];
    NSMutableArray* tagSalesArrayC = [self getArrayTagQposC];

    NSString* tag;
    NSString* tagC;


    //Se recorta la trama para obtener los Tag C
    NSArray *tramaRecortada = [tlv componentsSeparatedByString:@"9F12"];
    NSString *tramaTagsC = tramaRecortada[1];
    NSLog(@"onRequestOnlineProcess TRAMA RECORTADA C: %@",tramaTagsC);

    //Substring primera coincicendia en objective c ... -_-
    NSRange match = [tramaTagsC rangeOfString:@"C4"];
    NSString *tramaSoloC =@"C4";
    NSString *str1 = [tramaTagsC substringWithRange: NSMakeRange (0, match.location)];
    NSLog(@"onRequestOnlineProcess STR1 %@",str1);
    NSString *str2 = [tramaTagsC substringWithRange: NSMakeRange (match.location+match.length,(tramaTagsC.length-match.location)-match.length)];
    NSLog(@"onRequestOnlineProcess STR2 %@",str2);
    tramaSoloC = [tramaSoloC stringByAppendingString:str2];
    NSLog(@"onRequestOnlineProcess TRAMA RECORTADA C4: %@",tramaSoloC);
    
    //variables de cada c inicializadas
    NSString* tagC4=@"";
    NSString* tagC1=@"";
    NSString* tagC7=@"";
    NSString* tagC0=@"";

    //se crea un objeto tag
    NSMutableDictionary* tagCompleto = nil;

    //for para obtener los tag c de dspread
    for(NSInteger i = 0 ; i < [tagSalesArrayC count] ; i++){
        tagC = [tagSalesArrayC objectAtIndex:i];

        tagCompleto = [self getTagByname:tagC :tramaSoloC];
        NSString* len = tagCompleto[@"length"];
        NSString* valor =tagCompleto[@"value"];
        NSLog(@"onRequestOnlineProcess VALOR: %@",valor);
        NSLog(@"onRequestOnlineProcess LEN: %@",len);

        if(![len isEqualToString:@""]&&len!=nil){
            NSLog(@"onRequestOnlineProcess LEN: %s","ENTRE IF");
            NSInteger lenDec = [self hexaStringToInt:len];
            lenDec=lenDec*2;
            
            //substring de tres parametros
            tramaSoloC = [tramaSoloC substringFromIndex:[tagC length]+2+lenDec];
            NSLog(@"TLV DE MONDA %@:",tramaSoloC);

            if([tagC isEqualToString: @"C4"]){
                tagC4 = tagCompleto[@"value"];
            }else if([tagC isEqualToString: @"C1"]){
                tagC1 = tagCompleto[@"value"];
            }else if([tagC isEqualToString: @"C7"]){
                tagC7 = tagCompleto[@"value"];
            }else {
                tagC0 = tagCompleto[@"value"];
            }
        }
 
    }

    NSLog(@"onRequestOnlineProcess tagC4: %@",tagC4);
    NSLog(@"onRequestOnlineProcess tagC1: %@",tagC1);
    NSLog(@"onRequestOnlineProcess tagC7: %@",tagC7);

    //SE OBTIENEN LOS TAGS DE LA VENTA
    for(NSInteger i = 0 ; i < [tagSalesArray count] ; i++){
        tag = [tagSalesArray objectAtIndex:i];
        tlvTag = [mQPOSService getICCTag:EncryptType_plaintext cardType:0 tagCount:1 tagArrStr:tag];
        if(tlvTag == nil){
            tlvTag = @"";
        }
        tagSale = [tagSale stringByAppendingString:tlvTag[@"tlv"]];
    }

    NSLog(@"onRequestOnlineProcess tagSale: %@",tagSale);


    objectCard = nil;
    NSString *track2 = [mQPOSService getICCTag:EncryptType_encrypted cardType:0 tagCount:1 tagArrStr:TAG_57][@"tlv"];
    NSString *track2_plain = [mQPOSService getICCTag:EncryptType_plaintext cardType:0 tagCount:1 tagArrStr:TAG_57][@"tlv"];
    NSString *pan = [[track2_plain componentsSeparatedByString:TRACK2_SEPARADOR] objectAtIndex:0];
    pan = [pan substringFromIndex:4];
    NSString *lastfour = [pan substringFromIndex:pan.length-4];
    pan = [pan substringToIndex:8];
    pan = [pan stringByAppendingString:@"****"];
    pan = [pan stringByAppendingString:lastfour];
    
    NSString *tarjetaHabiente = [mQPOSService getICCTag:EncryptType_plaintext cardType:0 tagCount:1 tagArrStr:TAG_5F20][@"tlv"];
    if(![tarjetaHabiente isEqualToString:@""]){
        tarjetaHabiente = [tarjetaHabiente substringFromIndex:6];
        tarjetaHabiente = [self hexToString:tarjetaHabiente];
    }
    NSString *fechaExp = [mQPOSService getICCTag:EncryptType_plaintext cardType:0 tagCount:1 tagArrStr:TAG_5F24][@"tlv"];
    if(![fechaExp isEqualToString:@""]){
        fechaExp = [fechaExp substringFromIndex:6];
        fechaExp = [fechaExp substringWithRange:NSMakeRange(0, 4)];
    }
    NSString *label = [mQPOSService getICCTag:EncryptType_plaintext cardType:0 tagCount:1 tagArrStr:TAG_9F12][@"tlv"];
    if(![label isEqualToString:@""]){
        label = [label substringFromIndex:6];
    }
    NSString *arqc = [mQPOSService getICCTag:EncryptType_plaintext cardType:0 tagCount:1 tagArrStr:TAG_9F26][@"tlv"];
    if(![arqc isEqualToString:@""]){
        arqc = [arqc substringFromIndex:6];
    }
    NSString *aid = [mQPOSService getICCTag:EncryptType_plaintext cardType:0 tagCount:1 tagArrStr:TAG_84][@"tlv"];
    if(![aid isEqualToString:@""]){
        aid = [aid substringFromIndex:4];
    }
    tipoCuentaId = [self getTypeCardEmv:aid :label];
    NSString* franquicia = [self getFranquisieCardEmv:aid];
    NSString*track2_enc = [self getTrack2Data:track2][@"track2_enc"];
    NSString*ksn = [self getTrack2Data:track2][@"ksn"];
    // NSString *pinblock = [self getTagQposByName:TAG_C7:tlv][@"value"];
    // NSString *ksnPinblock= [self getTagQposByName:TAG_C1:tlv][@"value"];
    NSString *pinblock = tagC7;
    NSString *ksnPinblock= tagC1;
    NSLog(@" pinBLOCK %@:",pinblock);
    NSLog(@" ksn pinblock %@:",ksnPinblock);
    NSLog(@" arqc %@:",arqc);
    NSLog(@" track2 %@:",track2);
    NSLog(@" pan %@:",pan);
    NSLog(@" aid %@:",aid);
    NSLog(@" tarjetaHabiente %@:",tarjetaHabiente);
    NSLog(@" fechaExp %@:",fechaExp);
    NSLog(@" label %@:",label);
    NSLog(@" track2_plain %@:",track2_plain);
    NSLog(@" track2 %@:",track2_plain);
    NSLog(@" aid %@:",aid);
    objectCard = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  tarjetaHabiente, @"tarjetaHabiente",
                  fechaExp, @"fechaExp",
                  ksn, @"ksn",
                  ksnPinblock, @"ksnPinBlock",
                  pan, @"panEnmascarado",
                  pan, @"pan",
                  track2_enc, @"track2",
                  @(NO), @"isBanda",
                  @(YES), @"isChip",
                  CHIP, @"PosEntryMode",
                  pinblock,@"pinBlock",
                  tipoCuentaId,@"tipoCuentaId",
                  lastfour,@"ultimosCuatro",
                  franquicia,@"franquicia",
                  [NSNumber numberWithInt:MODE_EMV],@"tipoEntrada",
                  @(NO),@"fallback",
                  aid,@"aid",
                  tagSale,@"tagVenta",
                  arqc,@"arqc",
                  nil];
    cardInfo = [self convertDictionaryToString: objectCard];
    object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
              SUCCESFUL, @"code",
              @"success", @"message",
              cardInfo, @"data",
              nil];
    NSLog(@"onRequestOnlineProcess: %@",object);
    stateTx = APPROVAL;
    jsonString = [self convertDictionaryToString: object];
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:jsonString]];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
}

-(void) onRequestTransactionResult: (TransactionResult)transactionResult{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestTransactionResult");
    NSLog(@"+++QPOS PLUGIN onRequestTransactionResult+++");
    NSString *messageTextView = @"";
    if (transactionResult==TransactionResult_APPROVED) {
        NSLog(@"+++QPOS PLUGIN onRequestTransactionResult APPROVED+++");
        stateTx = APPROVAL;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }else if(transactionResult == TransactionResult_TERMINATED) {
        NSLog(@"+++QPOS PLUGIN onRequestTransactionResult TERMINATED+++");
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if(transactionResult == TransactionResult_DECLINED) {
        NSLog(@"+++QPOS PLUGIN onRequestTransactionResult DECLINED+++");
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if(transactionResult == TransactionResult_CANCEL) {
        NSLog(@"+++QPOS PLUGIN onRequestTransactionResult CANCEL+++");
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if(transactionResult == TransactionResult_CAPK_FAIL) {
        NSLog(@"+++QPOS PLUGIN onRequestTransactionResult CAPK_FAIL+++");
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if(transactionResult == TransactionResult_NOT_ICC) {
        NSLog(@"+++QPOS PLUGIN onRequestTransactionResult NOT_ICC+++");
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if(transactionResult == TransactionResult_SELECT_APP_FAIL) {
        NSLog(@"+++QPOS PLUGIN onRequestTransactionResult SELECT_APP_FAIL+++");
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if(transactionResult == TransactionResult_DEVICE_ERROR) {
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if(transactionResult == TransactionResult_CARD_NOT_SUPPORTED) {
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if(transactionResult == TransactionResult_MISSING_MANDATORY_DATA) {
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if(transactionResult == TransactionResult_CARD_BLOCKED_OR_NO_EMV_APPS) {
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if(transactionResult == TransactionResult_INVALID_ICC_DATA) {
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }else if(transactionResult == TransactionResult_NFC_TERMINATED) {
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }else{
        stateTx = DECLINE;
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }
    
}

-(void) onRequestUpdateWorkKeyResult:(UpdateInformationResult)updateInformationResult
{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestUpdateWorkKeyResult");
    NSLog(@"onRequestUpdateWorkKeyResult %ld",(long)updateInformationResult);
    if (updateInformationResult==UpdateInformationResult_UPDATE_SUCCESS) {
        NSLog(@" update workkey Success");
    }else if(updateInformationResult==UpdateInformationResult_UPDATE_FAIL){
        NSLog(@"Failed");
    }else if(updateInformationResult==UpdateInformationResult_UPDATE_PACKET_LEN_ERROR){
        NSLog(@"Packet len error");
    }
    else if(updateInformationResult==UpdateInformationResult_UPDATE_PACKET_VEFIRY_ERROR){
        NSLog(@"Packet vefiry error");
    }
    
}

-(void)onUpdatePosFirmwareResult:(UpdateInformationResult)result{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onUpdatePosFirmwareResult");
    NSLog(@"+++QPOS PLUGIN onUpdatePosFirmwareResult+++");
    if (result == UpdateInformationResult_UPDATE_SUCCESS) {
        [NSThread sleepForTimeInterval:20];
        [[QPOSService sharedInstance] connectBT:self.bluetoothAddress];
    } else if (result == UpdateInformationResult_UPDATE_FAIL) {
        flagUpdata = NO;
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  stateTx, @"code",
                  @"UpdateInformationResult_UPDATE_FAIL", @"message",
                  nil, @"data",
                  nil];
        NSString *jsonString = [self convertDictionaryToString: object];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:jsonString]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if (result == UpdateInformationResult_UPDATE_PACKET_LEN_ERROR) {
        flagUpdata = NO;
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  stateTx, @"code",
                  @"UpdateInformationResult_UPDATE_PACKET_LEN_ERROR", @"message",
                  nil, @"data",
                  nil];
        NSString *jsonString = [self convertDictionaryToString: object];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:jsonString]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else if (result == UpdateInformationResult_UPDATE_PACKET_VEFIRY_ERROR) {
        flagUpdata = NO;
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  stateTx, @"code",
                  @"UpdateInformationResult_UPDATE_PACKET_VEFIRY_ERROR", @"message",
                  nil, @"data",
                  nil];
        NSString *jsonString = [self convertDictionaryToString: object];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:jsonString]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    } else {
        flagUpdata = YES;
        NSLog(@"onUpdatePosFirmwareResult firmware updating...");
    }
}

-(void)completeTransacction : (NSMutableDictionary*)jsonResponse{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: completeTransacction");
    NSLog(@"+++QPOS PLUGIN completeTransacction+++%@:",[self convertDictionaryToString:jsonResponse]);
    NSString* tlv = jsonResponse[@"tagInfo"]; //@"9100102E4F1B34B0441F690012";//jsonResponse[@"tagInfo"];
    NSString* tlvAux;
    if([tlv isEqualToString: @""]){
        tlvAux = tlv;
        tlvAux = [@"8A023030" stringByAppendingString:tlvAux];
    }else{
        tlvAux=[tlv substringWithRange:NSMakeRange(2,4)];
        NSLog(@"+++QPOS PLUGIN completeTransacction+++%@:",tlvAux);
        NSInteger lenDec = [ tlvAux intValue];
        NSLog(@"+++QPOS PLUGIN completeTransacction+++%d:",lenDec);
        NSString* lhex = [NSString stringWithFormat:@"%X", lenDec];
        NSLog(@"+++QPOS PLUGIN completeTransacction+++%@:",lhex);
        if(lhex.length == 1){
            lhex = [@"0" stringByAppendingString:lhex];
        }
        tlvAux=[tlv substringToIndex:2];
        tlvAux=[tlvAux stringByAppendingString:lhex];
        tlvAux=[tlvAux stringByAppendingString:[tlv substringFromIndex:6]];
        tlvAux = [@"8A023030" stringByAppendingString:tlvAux];
    }
    [mQPOSService sendOnlineProcessResult:tlvAux];
}
-(void) onRequestBatchData: (NSString*)tlv{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestBatchData");
    NSLog(@"+++QPOS PLUGIN onRequestBatchData+++");
    NSLog(@"onBatchData %@",tlv);
    tlv = [@"batch data:\n" stringByAppendingString:tlv];
}

-(void) onReturnReversalData: (NSString*)tlv{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestBatchData");
    NSLog(@"+++QPOS PLUGIN onReturnReversalData+++");
    NSLog(@"onReversalData %@",tlv);
    tlv = [@"reversal data:\n" stringByAppendingString:tlv];
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:tlv]];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
}
-(void) resetStatusMode{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: resetStatusMode");
    NSLog(@"+++QPOS PLUGIN resetStatusMode+++");
    [mQPOSService resetPosStatus];
}
-(void) isInsertCard{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: isInsertCard");
    NSLog(@"+++QPOS PLUGIN isInsertCard+++");
    bool isExist = [mQPOSService syncIsCardExist:30];
    if(isExist){
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  @"1", @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK
                                                          messageAsString:[NSString stringWithFormat:[self convertDictionaryToString: object]]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }else{
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  @"0", @"code",
                  @"error", @"message",
                  nil, @"data",
                  nil];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR
                                                          messageAsString:[NSString stringWithFormat:[self convertDictionaryToString: object]]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }
}
//--------------------------------------------------------------------------------------------------------------------------------------------
//UPDATE_KEYS---------------------------------------------------------------------------------------------------------------------------------
-(void)updateIPEKKeysCute: (NSString*)xmlcute{
    NSLog(@"QPOS PLUGIN NUEVITO XML");
    NSLog(@"TAG QPOS file nuevito: %@",xmlcute);
    [mQPOSService updateEMVConfigByXml:xmlcute];
}
-(void)updateIPEKKeysMini: (NSString*)xmlmini{
    NSLog(@"QPOS PLUGIN NUEVITO XML");
    NSLog(@"TAG QPOS file nuevito: %@",xmlmini);
    [mQPOSService updateEMVConfigByXml:xmlmini];
}
-(void)updateIPEKKeys{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: updateIPEKKeys");
    indexKeyEMV = 0;
    indexEMV = 2;
    NSLog(@"QPOS PLUGIN updateIPEKKeys");
    NSLog(@"--------PRUEBAS-----");
    // NSData *data;
    NSString *emvAppCfg;
    NSString *emvCapkCfg;
    // if (arg0) {
    if (IS_TEST_VERSION) {
        emvAppCfg =[QPOSUtil byteArray2Hex:[self readLine:@"emv_app_pru"] ];
        emvCapkCfg =[QPOSUtil byteArray2Hex:[self readLine:@"emv_capk_pru"] ];
    } else {
        emvAppCfg =[QPOSUtil byteArray2Hex:[self readLine:@"emv_app_prod"] ];
        emvCapkCfg =[QPOSUtil byteArray2Hex:[self readLine:@"emv_capk_prod"] ];
    }
    NSLog(@"TAG QPOS emvAppCfg emv_app : %@",emvAppCfg);
    NSLog(@"TAG QPOS emvCapkCfg emv_capk: %@",emvCapkCfg);
    [mQPOSService updateEmvConfig:emvAppCfg emvCapk:emvAppCfg];
    // } 
    
    // else {
    //     CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:@""];
    //     [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    // }


    // ------------back----------

    // if (IS_TEST_VERSION) {
    //     data = [self readLine:@"upgrader"];
    // } else {
    //     data = [self readLine:@"upgrader_pro"];
    // }
    // flagUpdata = YES;
    
    // if (data != nil) {
    //     [[QPOSService sharedInstance] updatePosFirmware:data address:self.bluetoothAddress];
    //     dispatch_async(dispatch_queue_create(0, 0), ^{
    //         bool uploading = YES;
    //         while (uploading) {
    //             [NSThread sleepForTimeInterval:0.5];
    //             NSInteger progress = [mQPOSService getUpdateProgress];
    //             if (progress < 100) {
    //                 dispatch_async(dispatch_get_main_queue(), ^{
    //                     NSLog([NSString stringWithFormat:@"Current progress:%ld%%",(long)progress]);
    //                 });
    //                 continue;
    //             } else {
    //                 uploading = NO;
    //             }
    //             dispatch_async(dispatch_get_main_queue(), ^{
    //                 NSLog(@"升级完成");
    //             });
    //             break;
    //         }
    //     });
    // } else {
    //     flagUpdata = NO;
    //     CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@"Archivo no encontrado"]];
    //     [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    // }
    
}
-(void)onReturnCustomConfigResult:(BOOL)isSuccess config:(NSString*)resutl{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onReturnCustomConfigResult");
    NSLog(@"result: %@",resutl);
    if(isSuccess){
        object =nil;
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  @"1", @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK
                                                          messageAsString:[NSString stringWithFormat:[self convertDictionaryToString: object]]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }else{
        object =nil;
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  @"0", @"code",
                  @"error", @"message",
                  nil, @"data",
                  nil];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR
                                                          messageAsString:[NSString stringWithFormat:[self convertDictionaryToString: object]]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }
}
//--------------------------------------------------------------------------------------------------------------------------------------------
//INFO DEVICES--------------------------------------------------------------------------------------------------------------------------------
-(void)getQposId {
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getQposId");
    NSLog(@"QPOS PLUGIN getQposId");
    [self initPos];
    [mQPOSService getQPosId];
}
- (void)getInfoPOS{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: getInfoPOS");
    NSLog(@"QPOS PLUGIN getInfoPOS");
    [self initPos];
    [mQPOSService getQPosInfo];
    NSLog(@"---------------------");
}
-(void) onQposIdResult: (NSDictionary*)posId{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onQposIdResult");
    NSLog(@"QPOS PLUGIN onQposIdResult");
    NSString *aStr = [@"posId:" stringByAppendingString:posId[@"posId"]];
    
    NSString *temp = [@"psamId:" stringByAppendingString:posId[@"psamId"]];
    aStr = [aStr stringByAppendingString:@"\n"];
    aStr = [aStr stringByAppendingString:temp];
    
    temp = [@"merchantId:" stringByAppendingString:posId[@"merchantId"]];
    aStr = [aStr stringByAppendingString:@"\n"];
    aStr = [aStr stringByAppendingString:temp];
    
    temp = [@"vendorCode:" stringByAppendingString:posId[@"vendorCode"]];
    aStr = [aStr stringByAppendingString:@"\n"];
    aStr = [aStr stringByAppendingString:temp];
    
    temp = [@"deviceNumber:" stringByAppendingString:posId[@"deviceNumber"]];
    aStr = [aStr stringByAppendingString:@"\n"];
    aStr = [aStr stringByAppendingString:temp];
    
    temp = [@"psamNo:" stringByAppendingString:posId[@"psamNo"]];
    aStr = [aStr stringByAppendingString:@"\n"];
    aStr = [aStr stringByAppendingString:temp];
    
    NSLog(@"QPOS PLUGIN onQposIdResult",aStr);
    [self getInfoPOS];
}
-(void) onQposInfoResult: (NSDictionary*)posInfoData{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onQposInfoResult");
    NSLog(@"QPOS PLUGIN onQposInfoResult");
    NSLog(@"onQposInfoResult: %@",posInfoData);
    object =nil;
    NSString* jsonString;
    object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
              posInfoData[@"bootloaderVersion"], @"BootloaderVersion",
              posInfoData[@"firmwareVersion"], @"FirmwareVersion",
              posInfoData[@"hardwareVersion"], @"HardwareVersion",
              posInfoData[@"batteryPercentage"], @"batteryPercentage",
              posInfoData[@"batteryLevel"], @"batteryLevel",
              posInfoData[@"isCharging"], @"isCharging",
              posInfoData[@"isUsbConnected"], @"isUsbConnected",
              posInfoData[@"isSupportedTrack1"], @"isSupportedTrack1",
              posInfoData[@"isSupportedTrack2"], @"isSupportedTrack2",
              posInfoData[@"isSupportedTrack3"], @"isSupportedTrack3",
              posInfoData[@"updateWorkKeyFlag"], @"updateWorkKeyFlag",
              nil];
    jsonString = [self convertDictionaryToString: object];
    object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
              @"1", @"code",
              @"success", @"message",
              jsonString, @"data",
              nil];
    NSLog(@"onQposInfoResult: %@",object);
    jsonString = [self convertDictionaryToString: object];
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:jsonString]];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
}
//--------------------------------------------------------------------------------------------------------------------------------------------
//CONNECTION DEVICES--------------------------------------------------------------------------------------------------------------------------
- (void)connectionPOS:(NSString *)bluetoothAddress{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: connectionPOS");
    NSLog(@"QPOS PLUGIN connectionPOS");
    [self initPos];
    address = bluetoothAddress;
    self.bluetoothAddress = address;
    [mQPOSService connectBT:bluetoothAddress];
}
- (void)disconnectPOS:(NSString *)bluetoothAddress{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: disconnectPOS");
    NSLog(@"QPOS PLUGIN connectionPOS");
    [self initPos];
    [mQPOSService disconnectBT];
}
- (void)isConnectedPos{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: isConnectedPos");
    NSLog(@"QPOS PLUGIN isConnectedPos");
    [self initPos];
    if([mQPOSService isQposPresent]){
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }else{
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@""]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    };
}

-(void) onRequestUpdateKey {
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestUpdateKey");
}

-(void)UpdateEmvCfg {
    NSLog(@"QPOS_PLUGIN_NATIVE_I: UpdateEmvCfg");
    NSString *emvAppCfg;
    NSString *emvCapkCfg;
    printf("Argumentos para actualizar");
    if (IS_TEST_VERSION) {
        emvAppCfg = [QPOSUtil byteArray2Hex:[self readLine:@"emv_app_pru"] ];
        emvCapkCfg = [QPOSUtil byteArray2Hex:[self readLine:@"emv_capk_pru"] ];
    } else {
        emvAppCfg = [QPOSUtil byteArray2Hex:[self readLine:@"emv_app_prod"] ];
        emvCapkCfg = [QPOSUtil byteArray2Hex:[self readLine:@"emv_capk_prod"] ];
    }
    NSLog(@"TAG QPOS emvAppCfg emv_app : %@",emvAppCfg);
    NSLog(@"TAG QPOS emvCapkCfg emv_capk: %@",emvCapkCfg);
    if (emvAppCfg != nil && ![emvAppCfg  isEqual: @""] && ![emvCapkCfg isEqualToString:@""] && emvCapkCfg != nil) {
        [mQPOSService updateEmvConfig:emvAppCfg emvCapk:emvCapkCfg];
        NSLog(@"emv config is updating,pls wait a moment...");
    } else {
        NSLog(@"pls make sure that you've passed the right emv config file");
    }
    
}
-(void) onRequestQposConnected{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestQposConnected");
    NSLog(@"QPOS PLUGIN onRequestQposConnected");
    NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>onRequestQposConnected");
    if (flagUpdata) {
        flagUpdata = NO;
        [self UpdateEmvCfg];
    }else{
        NSString *jsonString= @"";
        stateTx = DECLINE;
        object =nil;
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  @"1", @"code",
                  @"success", @"message",
                  nil, @"data",
                  nil];
        isConnected = TRUE;
        jsonString = [self convertDictionaryToString: object];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:jsonString]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
        //[mQPOSService doSetShutDownTime:@"500"];
    }
}

-(void) onReturnUpdateIPEKResult:(BOOL) arg0 {
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onReturnUpdateIPEKResult");
    NSLog(@"QPOS PLUGIN onReturnUpdateIPEKResult");
    NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>onReturnUpdateIPEKResult");
    printf("Argumentos para actualizar");
    printf(arg0);
    NSString *emvAppCfg;
    NSString *emvCapkCfg;
    if (arg0) {
        if (IS_TEST_VERSION) {
            emvAppCfg =[QPOSUtil byteArray2Hex:[self readLine:@"emv_app_pru"] ];
            emvCapkCfg =[QPOSUtil byteArray2Hex:[self readLine:@"emv_capk_pru"] ];
        } else {
            emvAppCfg =[QPOSUtil byteArray2Hex:[self readLine:@"emv_app_prod"] ];
            emvCapkCfg =[QPOSUtil byteArray2Hex:[self readLine:@"emv_capk_prod"] ];
        }
        NSLog(@"TAG QPOS emvAppCfg emv_app : %@",emvAppCfg);
        NSLog(@"TAG QPOS emvCapkCfg emv_capk: %@",emvCapkCfg);
        [mQPOSService updateEmvConfig:emvAppCfg emvCapk:emvAppCfg];
    } else {
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:@""];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }
}

-(void) onRequestQposDisconnected{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestQposDisconnected");
    NSLog(@"QPOS PLUGIN onRequestQposDisconnected");
    NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>onRequestQposDisconnected");
    if (!flagUpdata) {
        NSString *jsonString= @"";
        stateTx = DECLINE;
        object =nil;
        object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                  @"0", @"code",
                  @"error", @"message",
                  nil, @"data",
                  nil];
        isConnected = FALSE;
        address = nil;
        self.bluetoothAddress = nil;
        jsonString = [self convertDictionaryToString: object];
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:jsonString]];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
    }
}
-(void) onRequestNoQposDetected{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestNoQposDetected");
    NSLog(@"QPOS PLUGIN onRequestNoQposDetected");
    NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>onRequestNoQposDetected");
    NSString *jsonString= @"";
    stateTx = DECLINE;
    object =nil;
    object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
              @"0", @"code",
              @"error", @"message",
              nil, @"data",
              nil];
    isConnected = FALSE;
    address = nil;
    self.bluetoothAddress = nil;
    jsonString = [self convertDictionaryToString: object];
    CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:jsonString]];
    [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
}
//--------------------------------------------------------------------------------------------------------------------------------------
//LIST DEVICES--------------------------------------------------------------------------------------------------------------------------
-(void)scanBluetooth{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: scanBluetooth");
    NSLog(@"QPOS PLUGIN scanBluetooth");
    if (bt == nil) {
        bt = [BTDeviceFinder new];
    }
    NSInteger delay = 0;
    NSLog(@"蓝牙状态:%ld",(long)[bt getCBCentralManagerState]);
    [bt setBluetoothDelegate2Mode:self];
    if ([bt getCBCentralManagerState] == CBCentralManagerStateUnknown) {
        while ([bt getCBCentralManagerState]!= CBCentralManagerStatePoweredOn) {
            NSLog(@"Bluetooth state is not power on");
            [self sleepMs:10];
            if(delay++==10){
                return;
            }
        }
    }
    [bt scanQPos2Mode:scanBluetoothTime];
}
-(void) actionTimer{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: actionTimer");
    if(TIMER==TIMER_OUT){
        NSLog(@"----------------ACTION TIMER STOP-------------------------%d",TIMER);
        if([nameAction isEqualToString:QPOS_GetCompanions]){
            if([allBluetooth count] != 0){
                [bt stopQPos2Mode];
                NSMutableArray *array = [[NSMutableArray alloc]init];
                object =nil;
                for(NSInteger i = 0 ; i < [allBluetooth count] ; i++){
                    object = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                              [allBluetooth objectAtIndex:i], @"id",
                              [allBluetooth objectAtIndex:i], @"name",
                              [allBluetooth objectAtIndex:i], @"address",
                              nil];
                    [object setObject:[NSNumber numberWithInt:1060]
                               forKey:[NSString stringWithFormat: @"class"]];
                    [array addObject:object];
                }
                NSError *error;
                NSData *jsonData = [NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted error:&error];
                NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
                CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:[NSString stringWithFormat:jsonString]];
                [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
            }else{
                CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@"ERROR"]];
                [self.commandDelegate sendPluginResult:pluginResult callbackId:commandLocal.callbackId];
            }
            [self stopTimer];
        }
        [self stopTimer];
    }else{
        NSLog(@"----------------ACTION TIMER ON-------------------------");
        TIMER++;
    }
}
-(void)stopTimer{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: stopTimer");
    [appearTimer invalidate];
    appearTimer = nil;
}
-(void)stopBluetooth{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: stopBluetooth");
    NSLog(@"+++stopBluetooth+++");
    if(is2ModeBluetooth && bt){
        [bt stopQPos2Mode];
    }
}
-(void)onBluetoothName2Mode:(NSString *)bluetoothName{
    NSLog(@"QPOS_PLUGIN_NATIVE_I: onBluetoothName2Mode");
    NSLog(@"+++onBluetoothName2Mode %@",bluetoothName);
    dispatch_async(dispatch_get_main_queue(),  ^{
        if(isTestBluetooth){
            if ([bluetoothName hasPrefix:@"MPOS8012400002"]) {
                [self stopBluetooth];
                [self connectionPOS:bluetoothName];
            }
        }else{
            if(bluetoothName != nil){
                if ([bluetoothName hasPrefix:@"MPOS"]) {
                    [allBluetooth addObject:bluetoothName];
                    NSLog(@"%tu",[allBluetooth count]);
                    NSLog(@"%@",allBluetooth);
                }
            }
            
        }
    });
}


-(void) onRequestIsServerConnected{NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestIsServerConnected");}
-(void) onRequestFinalConfirm{NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestFinalConfirm");}
-(void) onRequestTransactionLog: (NSString*)tlv{NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestTransactionLog");}
-(void) onError: (Error)errorState{NSLog(@"QPOS_PLUGIN_NATIVE_I: onError");}//pls del this Delegate
-(void) onDHError: (DHError)errorState{NSLog(@"QPOS_PLUGIN_NATIVE_I: onDHError");}//replace function onError
-(void) onRequestGetCardNoResult:(NSString *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestGetCardNoResult");}
-(void) onRequestSignatureResult:(NSData *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestSignatureResult");}

//add icc apdu 2014-03-11
-(void) onReturnPowerOnIccResult:(BOOL) isSuccess  KSN:(NSString *) ksn ATR:(NSString *)atr ATRLen:(NSInteger)atrLen{NSLog(@"QPOS_PLUGIN_NATIVE_I: onReturnPowerOnIccResult");}
-(void) onReturnPowerOffIccResult:(BOOL) isSuccess{NSLog(@"QPOS_PLUGIN_NATIVE_I: onReturnPowerOffIccResult");}
-(void) onReturnApduResult:(BOOL)isSuccess APDU:(NSString *)apdu APDU_Len:(NSInteger) apduLen{NSLog(@"QPOS_PLUGIN_NATIVE_I: onReturnApduResult");}

//add set the sleep time 2014-03-25
-(void) onReturnSetSleepTimeResult:(BOOL)isSuccess{NSLog(@"QPOS_PLUGIN_NATIVE_I: onReturnSetSleepTimeResult");}
//add  2014-04-02
-(void) onRequestCalculateMac:(NSString *)calMacString{NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestCalculateMac");}
//add 2014-04-11

-(void) onRequestPinEntry{NSLog(@"QPOS_PLUGIN_NATIVE_I: onRequestPinEntry");}
-(void) onReturnSetMasterKeyResult: (BOOL)isSuccess{NSLog(@"QPOS_PLUGIN_NATIVE_I: onReturnSetMasterKeyResult");}

-(void) onReturnBatchSendAPDUResult:(NSDictionary *)apduResponses{NSLog(@"QPOS_PLUGIN_NATIVE_I: onReturnBatchSendAPDUResult");}
-(void) onReturniccCashBack: (NSDictionary*)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: onReturniccCashBack");}
-(void) onLcdShowCustomDisplay: (BOOL)isSuccess{NSLog(@"QPOS_PLUGIN_NATIVE_I: onLcdShowCustomDisplay");}

-(void) onDownloadRsaPublicKeyResult:(NSDictionary *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: onDownloadRsaPublicKeyResult");}
-(void) onPinKeyTDESResult:(NSString *)encPin{NSLog(@"QPOS_PLUGIN_NATIVE_I: onPinKeyTDESResult");}
-(void) onGetPosComm:(NSInteger)mode amount:(NSString *)amt posId:(NSString*)aPosId{NSLog(@"QPOS_PLUGIN_NATIVE_I: onGetPosComm");}
-(void) onUpdateMasterKeyResult:(BOOL)isSuccess aDic:(NSDictionary *)resultDic{NSLog(@"QPOS_PLUGIN_NATIVE_I: onUpdateMasterKeyResult");}
-(void) onEmvICCExceptionData: (NSString*)tlv{NSLog(@"QPOS_PLUGIN_NATIVE_I: onEmvICCExceptionData");}
-(void) onAsyncResetPosStatus:(NSString *)isReset{NSLog(@"QPOS_PLUGIN_NATIVE_I: onAsyncResetPosStatus");}
//MIFARE CARD CALLBACK FUNCTION
-(void) onSearchMifareCardResult:(NSDictionary *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: onSearchMifareCardResult");}
-(void) onVerifyMifareCardResult:(BOOL)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: onVerifyMifareCardResult");}
-(void) onReadMifareCardResult:(NSDictionary *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: onReadMifareCardResult");}
-(void) onWriteMifareCardResult:(BOOL)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: onWriteMifareCardResult");}
-(void) onOperateMifareCardResult:(NSDictionary *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: onOperateMifareCardResult");}
-(void) getMifareCardVersion:(NSDictionary *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: getMifareCardVersion");}
-(void) getMifareReadData:(NSDictionary *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: getMifareReadData");}
-(void) getMifareFastReadData:(NSDictionary *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: getMifareFastReadData");}
-(void) writeMifareULData:(NSString *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: writeMifareULData");}
-(void) verifyMifareULData:(NSDictionary *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: verifyMifareULData");}
-(void) onFinishMifareCardResult:(BOOL)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: onFinishMifareCardResult");}
-(void) batchReadMifareCardResult:(NSDictionary *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: batchReadMifareCardResult");}
-(void) batchWriteMifareCardResult:(NSDictionary *)result{NSLog(@"QPOS_PLUGIN_NATIVE_I: batchWriteMifareCardResult");}
-(void) onGetKeyCheckValue:(NSDictionary *)checkValueResult{NSLog(@"QPOS_PLUGIN_NATIVE_I: onGetKeyCheckValue");}


//--------------------------------------------------------------------------------------------------------------------------------------
//COMMANDS------------------------------------------------------------------------------------------------------------------------------
-(void)QPOS_GetCompanions:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_GetCompanions];
    
}
-(void)QPOS_getConnectDevice:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_getConnectDevice];
    
}
-(void)QPOS_DisconnectDevice:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_DisconnectDevice];
    
}
-(void)QPOS_GetStatusBattery:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_GetStatusBattery];
    
}
-(void)QPOS_IsConnectDevice:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_IsConnectDevice];
    
}
-(void)QPOS_ConfigurationInitial:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_ConfigurationInitial];
    
}
-(void)QPOS_ConfigurationInitialmini:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_ConfigurationInitialmini];
    
}
-(void)QPOS_ConfigurationInitialcute:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_ConfigurationInitialcute];
    
}
-(void)QPOS_StartTransaction:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_StartTransaction];
    
}
-(void) QPOS_DataTransaction:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_DataTransaction];
    
}
-(void) QPOS_CompleteTransaction:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_CompleteTransaction];
    
}
-(void) QPOS_StopTransaction:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_STOP_TRANSACTION];
    
}
-(void) QPOS_IsInsertCard:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_IS_INSERT_CARD];
    
}
-(void) QPOS_BandCardPin:(CDVInvokedUrlCommand *)command{
    
    [self executeMyMethodWithCommand:command withActionName:QPOS_BANDCARDPIN];
    
}



-(id)init:(CDVInvokedUrlCommand*)command{
    self = [super init];
    if(self != nil){
        [self initPos];
    }
    commandLocal = command;
    return self;
}
-(void)initPos{
    if (mQPOSService == nil) {
        mQPOSService = [QPOSService sharedInstance];
    }
    [mQPOSService setDelegate:self];
    [mQPOSService setQueue:nil];
    [mQPOSService setPosType:PosType_BLUETOOTH_2mode];
    if (bt== nil) {
        bt = [[BTDeviceFinder alloc]init];
    }
    allBluetooth = [[NSMutableArray alloc]init];
}


-(void)executeMyMethodWithCommand:(CDVInvokedUrlCommand*)command withActionName:(NSString *)name{
    [self init: command];
    nameAction = name;
    TIMER = 0;
    if ([name isEqualToString:QPOS_GetCompanions]) {
        appearTimer = [NSTimer scheduledTimerWithTimeInterval:0.5  target:self selector:@selector(actionTimer) userInfo:nil repeats:YES];
    }
    [self.commandDelegate runInBackground:^{
        NSLog(@"QPOS PLUGIN executeMyMethodWithCommand %@",name);
        if (name != nil) {
            if ([name isEqualToString:QPOS_GetCompanions]) {
                scanBluetoothTrieds = 0;
                [self scanBluetooth];
            }else if([name isEqualToString:QPOS_getConnectDevice]){
                [self connectionPOS:[commandLocal.arguments objectAtIndex:0]];
            }else if([name isEqualToString:QPOS_IsConnectDevice]){
                [self isConnectedPos];
            }else if([name isEqualToString:QPOS_DisconnectDevice]){
                [self disconnectPOS:address];
            }else if([name isEqualToString:QPOS_GetStatusBattery]){
                [self getQposId];
            }else if([name isEqualToString:QPOS_ConfigurationInitial]){
                [self updateIPEKKeys];
            }else if([name isEqualToString:QPOS_ConfigurationInitialmini]){
                [self updateIPEKKeysMini:[commandLocal.arguments objectAtIndex:0]];
            }else if([name isEqualToString:QPOS_ConfigurationInitialcute]){
                [self updateIPEKKeysCute:[commandLocal.arguments objectAtIndex:0]];
            }else if([name isEqualToString:QPOS_StartTransaction]){
                [self startTransaccion:[commandLocal.arguments objectAtIndex:0]];
            }else if([name isEqualToString:QPOS_DataTransaction]){
                [self getDataTransaccion];
            }else if([name isEqualToString:QPOS_CompleteTransaction]){
                NSMutableDictionary* json = [commandLocal.arguments objectAtIndex:0];
                [self completeTransacction:json];
            }else if([name isEqualToString:QPOS_STOP_TRANSACTION]){
                [self resetStatusMode];
            }else if([name isEqualToString:QPOS_IS_INSERT_CARD]){
                [self isInsertCard];
            }else if([name isEqualToString:QPOS_BANDCARDPIN]){
                [self getSwipePin: [commandLocal.arguments objectAtIndex:0]];
            }
            else{
                CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@"no method found to %@",name]];
                [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
            }
        }else{
            //callback
            CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:[NSString stringWithFormat:@"no method found to %@",name]];
            [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
        }
    }];
}

@end
