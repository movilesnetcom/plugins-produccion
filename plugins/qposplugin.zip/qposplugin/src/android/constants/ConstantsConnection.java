package org.apache.cordova.posPlugin.constants;

/**
 * Created by david.ordaz on 20/03/2018.
 */
public class ConstantsConnection {

  public static final boolean AUTO  = true;
  public static final int BOND_TIME = 180000;
}
