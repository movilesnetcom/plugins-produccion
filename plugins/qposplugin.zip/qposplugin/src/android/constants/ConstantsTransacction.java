package org.apache.cordova.posPlugin.constants;

/**
 * Created by david.ordaz on 20/03/2018.
 */
public class ConstantsTransacction {

  public static final String CURRENCY_TYPE   = "0170";
  public static final String CENTS           = "00";
  public static final String CASHBACK_AMOUNT = "0";



}
