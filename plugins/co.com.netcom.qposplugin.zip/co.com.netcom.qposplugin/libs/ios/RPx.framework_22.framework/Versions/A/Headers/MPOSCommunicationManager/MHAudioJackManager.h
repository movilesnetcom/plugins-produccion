//
//  MHAudioJackManager.h
//  AudioDemo
//
//  Created by Wu Robert on 10/7/15.
//  Copyright (c) 2015 Wu Robert. All rights reserved.
//

#import "AudioJackManager.h"

@interface MHAudioJackManager : AudioJackManager

+(MHAudioJackManager*)sharedInstance;

@end
