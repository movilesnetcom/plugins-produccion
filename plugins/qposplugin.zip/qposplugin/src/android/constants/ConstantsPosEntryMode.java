package org.apache.cordova.posPlugin.constants;

/**
 * Created by david.ordaz on 22/03/2018.
 */
public class ConstantsPosEntryMode {

  public static final String MAGNETIC_SWIP =  "021";

  public static final String CHIP = "051";

  public static final String FALLBACK = "801";

  public static final String CONTACTLESS = "071";

  public static final String CONTACTLESS_BAND = "911";

}
