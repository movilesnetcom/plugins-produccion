package org.apache.cordova.posPlugin.constants;

/**
 * Created by david.ordaz on 02/04/2018.
 */
public class ConstantsFranchise {

  public static final String MAESTRO        = "MAESTRO";
  public static final String MASTERCARD     = "MASTERCARD";
  public static final String VISA_ELECTRON  = "VISA_ELECTRON";
  public static final String VISA_CREDITO   = "VISA_CREDITO";
  public static final String DINNER_CREDITO = "DINNER_CREDITO";
  public static final String AMEX           = "AMEX";

}
