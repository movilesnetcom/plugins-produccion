package org.apache.cordova.posPlugin.constants;

/**
 * Created by david.ordaz on 20/03/2018.
 */
public class ConstantsCodeResponse {

  public static final String SUCCESFUL = "1";
  public static final String FAILED = "0";
  public static final String ERROR = "-1";

}
