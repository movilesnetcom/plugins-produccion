package co.com.netcom.qposplugin.android.constants;

/**
 * Created by david.ordaz on 02/04/2018.
 */
public class ConstantsTypeCard {

  public static String AHORRO    = "10";
  public static String CORRIENTE = "20";
  public static String CREDITO   = "30";
  public static String DEBITO    = "00";
}
