package org.apache.cordova.posPlugin.constants;

/**
 * Created by david.ordaz on 23/03/2018.
 */
public class ConstantsModeEntry {

  public static final int  MAGNETIC_SWIPE		= 1;
  public static final int  EMV		            = 2;
  public static final int  CONTACTLESS		    = 3;

}
